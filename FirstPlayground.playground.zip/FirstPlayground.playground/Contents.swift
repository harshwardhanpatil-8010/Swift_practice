import Cocoa

var greeting = "Hello, playground"
print(greeting)
print("Hello world")
print("ios")
print("hello")

//eye button for the quick look
//inline button is the square beside the output
//select automatic run
//Right side column is for output
//Bottom side is the console or debug area
//Playground is a special document which comes with xcode

var introduction = "Hello myself Harshwardhan Patil"
print(introduction)

