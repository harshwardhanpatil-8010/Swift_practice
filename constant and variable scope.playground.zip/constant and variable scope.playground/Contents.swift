import UIKit

//Scope

//global scope - defined outside the function
//local scope - defined inside a function using {}

var globalVariable = 10  //Global Scope
print(globalVariable)



func printingNumber() {
    var num = 25  //Local Scope
    print("Num = \(num)")
}
printingNumber()


//Global variables cannot be accessed in a function in Swift

var age = 35
@MainActor   //To access the global variable inside a function we need to use @MainActor in front of a function
func printAge() {
    print("Age is \(age)")
}
printAge()

func printBottleCounts() {
    let bottleCount = 45
    print("Inside the function Bottle Count = \(bottleCount)")
}
printBottleCounts()
//Local variables cannot be accessed outside the scope
//print("Outside the function Bottle counts = \(bottleCount)")


func printFiveNumbers() {
    var name = "Harshwardhan"
    for index in 1...5 {
        print("\(index) \(name)")
    }
//print("Index = \(index)")  //Function reference - index variable cannot be accessed because it is outside the for loop scope so it is inside the function scope but outside the for loop scope
    print("Name = \(name)")
}
printFiveNumbers()


//Variable Shadowing
// 1) Same variable name maybe with different values one in the local scope and one in global scope, the reference changes on the basis of the scope where it is being used
//Memory allocation will be different on the basis of scope and data
let points = 100
for index in 1...3 {
    let points = 300
    print(index + points)
}

print("the points outside the for loop are \(points)")


// 2) in optional binding when using same variable name on left side and right side then it is also called as variable shadowing
var name: String? = "Harshwardhan"
if let name = name {
    print("name = \(name)")
} else {
    print("Name value is nil")
}

// 3) shadowing and initializers - in init we give same variable name on right side and left side e.g. - self.name = name
struct Person {
    var name: String
    var id: Int
    init(name: String, id: Int) {
        self.name = name  //Self is used to hold current object address
        self.id = id
    }
}

var personObject = Person(name: "Harshwardhan", id: 1)
print("Name \(personObject.name)")
print("ID \(personObject.id)")
