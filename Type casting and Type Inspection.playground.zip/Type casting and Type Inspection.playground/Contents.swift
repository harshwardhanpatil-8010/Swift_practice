import UIKit

//Type Casting and Type Inspection

//Create a class Employee
class Employee {
    var name: String
init(name: String) {
    self.name = name
    }
    func work() {
        print("\(self.name) Employee is working ")
    }
}


//Hierachical Inheritance
//Subclass - Manager
class Manager: Employee {
 func conductingMeeting() {
        print("Manager is conducting meeting")
    }
}

//Subclass - Developer
class Developer: Employee {
    func writeCode() {
        print("Developer writes code")
    }
}

//Subclass - Intern
class Intern: Employee {
    func learn() {
        print("Intern is learning")
    }
}

var staff: [Employee] = [
    Developer(name: "Harshwardhan"),
    Manager(name: "Harshwardhan"),
    Intern(name: "Harshwardhan"),
    Manager(name: "Harsh")
]

for staff in staff {
    staff.work()
}


// has a relationship is called association
// is a relationship is called inheritance

//////////////////////////--------------------------------------------------------
//Type Inspection
//using is keyword

for person in staff {
    if person is Manager {
        print("\(person.name) is a Manager")
    } else if person is Developer {
        print("\(person.name) is a Developer")
    } else if person is Intern {
        print("\(person.name) is a Intern")
    }
}

print("******************************")

//Type Casting
//using as?
for person in staff {
    //Type casting to call subclass-specific methods
    if let manager = person as? Manager {
        manager.conductingMeeting()
    } else if let developer = person as? Developer {
        developer.writeCode()
    } else if let intern = person as? Intern {
        intern.learn()
    }
}
print("************************************")
//Employee example extended to include forced casting(as!)
//Forced Unwrapping
for person in staff {
    //This is a safe if we know the type for sure
    if person is Manager {
        let manager = person as! Manager //Force Cast
        manager.conductingMeeting()
    }
}


////-----------------------------
//Type Alias - Any
var items: [Any] = [5, "Bill", 6.7]
print(items[0])

if let firstItem = items[0] as? Int {
    print(firstItem + 4)
}
