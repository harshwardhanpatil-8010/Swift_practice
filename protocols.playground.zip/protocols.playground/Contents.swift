import UIKit
import Foundation
//Protocols


//Custom string convertible protocol

class Student: CustomStringConvertible, Comparable {
    
    static func < (lhs: Student, rhs: Student) -> Bool {
        return lhs.rollNo < rhs.rollNo
    }
    static func == (lhs: Student, rhs: Student) -> Bool {
        return lhs.rollNo == rhs.rollNo && rhs.firstName == lhs.firstName && rhs.lastName == lhs.lastName
    }
    var description: String { return "The Name of the Student \(firstName) \(lastName)"}
    var rollNo: Int
    
    var firstName: String
    var lastName: String
    init(rollNo: Int, firstName: String, lastName: String) {
        self.rollNo = rollNo
        self.firstName = firstName
        self.lastName = lastName
    }
}

var Student1 = Student(rollNo: 1, firstName: "Harshwardhan", lastName: "Patil")
var Student2 = Student(rollNo: 2, firstName: "Nevin", lastName: "Abraham")

print(Student1)
if Student1 == Student2{
    print("They are equal ")
} else {
    print("They are not equal")
}






//////////////////
class Shoe: CustomStringConvertible {
    var description: String { return "The Show is of \(color) color and size is \(size)"}
    let size: Int
    let color: String
    init(size: Int, color: String) {
        self.size = size
        self.color = color
    }
}

var myShoe = Shoe(size: 10, color: "Black")

print(myShoe)


//Codable  or Encoders
//should have import Foundation
class myData {
    let name: String
    let age: Int
    
    init(name: String, age: Int) {
        self.name = name
        self.age = age
    }
}
let name =  myData(name: "Harshwardhan", age: 20)


//Codable Protocol
class IOSSDP: Codable {
    var hostInstitute: String
    var cohort: String
    var size: Int
    
    init(hostInstitute: String, cohort: String, size: Int) {
        self.hostInstitute = hostInstitute
        self.cohort = cohort
        self.size = size
    }
}
var mitiosSDP = IOSSDP(hostInstitute: "MITWPU", cohort: "2025", size: 100)

var jsonEncoder = JSONEncoder()
if let jsonData = try?jsonEncoder.encode(mitiosSDP) {
    if let jsonString = String(data: jsonData, encoding: .utf8) {
        print(jsonString)
    }
}



