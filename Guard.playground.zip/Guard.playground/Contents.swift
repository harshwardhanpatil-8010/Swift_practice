import UIKit

//Guard
//opposite of if
//without entering the whole code we can use guard to check condition first
//It is used to remove the use of if else mountain
//If the condition which is true will only be executed

/*
guard condition else {
condition False : Some code
}
condition True : some code
*/

var birthdayIsToday = true
var invitedGuests: [String] = ["hi"]
var cakeCandlesLit = false
@MainActor
func singHappyBirthday() {
    guard birthdayIsToday else {
        print("No one has a birthday today.")   //If it is false then this output
        return
    }
    
    guard !invitedGuests.isEmpty else {
        print("It is just a family party")  //If it is empty then this output
        return
    }
    
    guard cakeCandlesLit else {
        print("The cake is not lit")   //If it is false then this output
        return
    }
}

singHappyBirthday()


print("Using if  else")
func divide(_ number: Double, by divisor: Double) {
    if divisor != 0.0 {
        let result = number / divisor
        print(result)
    }
    return
}
divide(10.0, by: 4.0)

print("using guard")
func divide1(_ number: Double, by divisor: Double) {
    guard divisor != 0.0 else {
        print("Inside Guard")
        return
    }
    let result = number / divisor
    print(result)
}
divide1(10.0, by: 0.0)
divide1(10.0, by: 4.0)


//Guard with optionals
var title: String? = nil
var price: Double? = 300.0
var pages: Int? = nil

func processBook(title: String?, price: Double?, pages: Int?) {
    if let title = title, let price = price, let pages = pages {
        print("Title: \(title), Price: \(price), Pages: \(pages)")
    }
}
processBook(title: title, price: price, pages: pages)


func processBook1(title: String?, price: Double?, pages: Int?) {
    guard let thetitle = title, let theprice = price, let thepages = pages else {
        return
    }
    print("Title: \(thetitle), Price: \(theprice), Pages: \(thepages)")
}
processBook1(title: title, price: price, pages: pages)
