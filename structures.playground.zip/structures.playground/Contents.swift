import UIKit

//Structures
//Struct is value type
//User defined types
//Capitalize type names
//use lowercase for property names
struct Person {
    var name: String
    var age: Int
    
    func sayHello() {
        print("Hello myself \(name) and my age is \(age)")
    }
}
var person = Person(name: "Harshwardhan", age: 19)
print(person.name)
print(person.age)
print(person.name, person.age)
//to access the property use personName.property
person.age = 20
print(person.age)
person.sayHello()


//Initializers
let string = String()
let bool = Bool()
let int = Int()

////////
//Default Initializer
struct Odometer {
    var count: Int = 0
}
//var odometer = Odometer()
//print(odometer.count)

var odometer = Odometer(count: 1000)
print(odometer.count)



//Member wise initializers
struct bankAccount {
    var accountNumber: Int
    var balance: Double = 0
}
let account = bankAccount(accountNumber: 320332, balance: 10000.0)
let anotherAccount = bankAccount(accountNumber: 122434)
print(account)
print(anotherAccount)




//Custom Initializers
struct Temperature {
    var celsius: Double
    init(celsius: Double) {
        self.celsius = celsius
    }  //self is used to hold the current object address and it is not needed if there are two different variables then you don't need to declare it with self but if there are same variable name for var and also the init then we need to declare it using self
    init(farenheit: Double) {
        celsius = (farenheit - 32) / 1.8
    }
}
//let currentTemperature = Temperature(celsius: 25.0)
//let boiling = Temperature(farenheit: 212.0)

//print(currentTemperature.celsius)
//print(boiling.celsius)



//Instance methods
//Any property mentioned in a struct like var or a let they become immutable means they are constant
struct Size {
    var height: Double
    var width: Double
    //use mutating to make any function mutable
    mutating func area() -> Double {
        height = 30.0
        return height * width
    }
}
var someSize = Size(height: 10.0, width: 20.0)
print(someSize.area())

///////////
struct Odometer2 {
    var count: Int = 0
    
    mutating func increment() {
        count += 1
    }
    mutating func increment(by amount: Int) {
        count += amount
    }
}

var odometer1 = Odometer2()
odometer1.increment()
print(odometer1.count)
odometer1.increment()
print(odometer1.count)


var odometer2 = Odometer2()
odometer2.increment()
print(odometer2.count)
odometer2.increment(by: 20)
print(odometer2.count)


//Computed properties
struct Temperature1 {
    var celsius: Double
    
    var fahrenheit: Double {
     celsius * 1.8 + 32
    
    }
    var kelvin: Double {
        celsius + 273.15
    }
}
    let currentTemperature = Temperature1(celsius: 0.0)
    print(currentTemperature.fahrenheit)
    

//Property observer
struct StepCounter {
    
    var totalSteps: Int = 0 {
        //newValue and oldValue are the keywords which comes with willSet and didSet
      
            willSet {
                print("About to set totalSteps to \(newValue)")
                //Cannot use oldValue in willSet only use newValue
            }
            didSet {
                //cannot use newValue in didSet only use oldValue
                if totalSteps > oldValue {
                    
                    print("Added \(totalSteps - oldValue) steps")
                }
            }
        }
    mutating func steps() {
        totalSteps += 1
    }
}
var counter = StepCounter()
counter.totalSteps = 300
counter.steps()


//type properties and methods
//You don't need to create any instance when using static you can access any property by the structName.propertyName
struct Temperature2 {
    //@MainActor is used to remove the concurrency error if declaring a static with a variable
    @MainActor static var boilingPoint = 100.0
    
    static func convertedfromFahrenheit(_ temperatureInFahrenheit: Double) -> Double {
        (((temperatureInFahrenheit - 32) * 5) / 9)
    }
}

let boilingPoint1 = Temperature2.boilingPoint
let currentTemperature1 = Temperature2.convertedfromFahrenheit(99)
let positiveNumber = abs(-4.14)
print(boilingPoint1)
print(currentTemperature1)




//Copying
var someSize1 = Size(height: 100, width: 200)
var anotherSize1 = someSize1
someSize1.width = 500
print(someSize1.width)
print(anotherSize1.width)


//self
//not required with computed properties
//required with initializers

