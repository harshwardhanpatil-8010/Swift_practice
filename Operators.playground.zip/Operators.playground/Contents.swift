import Cocoa

var greeting = "Hello, playground"
//Arithmetic operations
var myScore = 8 * 6
var myOpponentScore: Float  = 100/3
var finalResult = Float(myScore) + myOpponentScore
print("The final score is: \(finalResult)")


//myScore = myScore + 52
myScore += 52
myScore -= 32
myScore /= 2
myScore *= 5

print(myScore)

var x = 5
var y = 15
var z = 3
var result = Double(x + y) / Double(z)
print(result)


//unnary operators
var three = 3
var minusThree = -three
var minusOfMinusThree = -minusThree
print(minusOfMinusThree)


//Comparison Operators
3 != 2
(1, "zebra") < (2, "apple")


//Ternary conditional operators
var validAge = 21
var myAge = 18 < validAge ? "You are minor" : "eligible"


//Nil Coalescing Operator
var groupPartner: String? = "Unnatti"
//var groupPartner: String? = nil
var projectPartner = groupPartner ?? "Harshwardhan"
print(projectPartner)

var defaultColor: String? = "Red"
var finalPintColor = defaultColor ?? "Blue"
print(finalPintColor)

//Closed Range operators

//full range
for index in 1...10{
    print("2 * \(index) = \(index * 2)")
}

//Half open range
for values in 1..<10
{
    print(values)
}

//var list = [11, 22, 45 ,62, 202]
//for values in list {
//    if values%2 == 0 {
//        print(values)
//    }
//}


//Logical Operators
var hasDoorCode = true
var retinaScanPassed = false

//AND operator
if hasDoorCode && retinaScanPassed {
    print("allowed")
} else {
    print("you cannot enter")
}

//OR operator
let fingerPrintScan = true
if fingerPrintScan || retinaScanPassed{
    print("allowed")
}
