import UIKit

//Q 1
func area(length: Double, width: Double) -> Double {
    length * width
}
print(area(length: 20, width: 30))

//Q 2
func reverse(string: String) -> String {
    return String(string.reversed())
}
print(reverse(string: "Harshwardhan"))

//Q3
func factorial(of number: Int) -> Int {
    var fact: Int
    if number == 0 || number == 1 {
         fact = 1
    } else {
        fact = number * factorial(of: number - 1)
        
    }
    return fact
}
print(factorial(of: 5))

//Q 4
func swapValues(a: inout Int, b: inout Int) {
    var temp: Int
    temp = a
    a = b
    b = temp
}

var x = 10
var y = 20
print("Before Swapping: X = \(x), Y = \(y)")
swapValues(a: &x, b: &y)
print("After Swapping: X = \(x), Y = \(y)")

//Q 5

