import UIKit

var greeting = "Hello, playground"
//collectiobn types
//Array
//Dictionary
var name: [String] = ["Harshwardhan", "Nevin", "Unnatti", "Zeeshan"]
//the brackets used for arrays [] are called subscripts
print(name)
var numbers: [Int8] = [5, 8, -1, 40 ,24]  //Int8 = 1bytes = 8bits  and Int = 4 bytes = 16bits
print(numbers)

//contains is the function to check whether the element is inside the array
if numbers.contains(8) {
    print("Array is having the element 8")
} else {
    print("Number is not present")
}

//Different ways to create an Array
//var myArray: [Int] = []
//var myArray: Array<Int> = []
//var myArray = [Int]()

var myArray = [Int]()
print(myArray)

//Value type
var myArray1 = [Int](repeating: 0, count: 40)
print(myArray1)
print("Count = \(myArray1.count)")


var mySecondArray = [Int]()
print(mySecondArray)

if mySecondArray.isEmpty {
    print("My array is empty")
} else {
    
    print("my array is not empty")
}



//accessing an array using index
var name1: [String] = ["Harshwardhan", "Nevin", "Unnatti", "Zeeshan"]
print(name1[0])
print(name1)

//Replacing an element in an array
name1[1] = "newperson"
print(name1)


//Append
name1.append("Nevin")
print(name1)

print(name1.count)

//To add a new element you have to use append you cannot add elements using indexing

//To add some more data in same element
print(name1[0].append("Ios"))
print(name1[0])


var strArray: [String] = ["swift", "IOS", "Xcode"]
print(strArray)
strArray.append("Design")
print(strArray)

//Instead of append we can also use += concatenation
strArray += ["SwiftUI", "AppDesgin"]
print(strArray)

//When the function is not returning anything then it gives an empty array


//Insert an element
strArray.insert("keynote", at: 0)
print(strArray)

print(strArray.count)
strArray.insert("Swift", at: 7) //You need to insert elements in a contiuous manner only
print(strArray)
print(strArray.count)
print(strArray[7])


//Remove elements from an array
var element = strArray.remove(at: 2)
print("Element removed from an array = \(element)")
print(strArray)

//Remvoe last element
var lastElement = strArray.removeLast()
print(lastElement)
print(strArray)

//Remove all elements
//strArray.removeAll()
print(strArray)

//droplast
//Drops last element and provides you the remaining arrays
var droppedValue = strArray.dropLast() // if we write a number in the droplast function like 2 or 3 then it will remove last 2 or 3 elements
print("Dropped last = \(droppedValue)")

print(strArray)


//Combining an Array
var firstArray = [1, 2, 3]
var secondArray = [4, 5, 6]
var combinedArray = firstArray + secondArray
print(combinedArray)

//Two dimensional array
var combinedArray1 = [firstArray, secondArray]
print(combinedArray1)

print(combinedArray1[0]) // [1, 2, 3]

//To print a specific element from a 2D array
print(combinedArray1[0][1]) // 2


var array1 = [Int](repeating: 1, count: 1)
var array2 = [Int](repeating: 2, count: 2)
var array3 = [Int](repeating: 3, count: 3)
var array4 = [Int](repeating: 4, count: 4)
var array5 = [Int](repeating: 5, count: 5)

var combinedArray2 = [array1, array2, array3, array4, array5]
print(combinedArray2)


var array6: [[Int]] = [[]]
print(array6)


//Dictionaries

//var myDictionary = [String: Int]()
//var myDictionary = Dictionary<String, Int>()
//var myDictionary: [String: Int] = [:]
//dictionary = key: Value

var scores = ["Richard": 500, "Luke": 400, "Cheryl": 800]
print(scores)

///Adding or modifying  a key, value
scores["Richard"] = 999
print(scores)

scores["player11"] = 999
print(scores)

//You cannot fetch the key on the basis of value
//the output will not be in continuous manner it will only be in random manner


scores.updateValue(777, forKey: "player11")
print(scores)

//var temp = scores.updateValue(780, forKey: "player")
//print(temp)
//If key is not found then it returns nil
//when you are trying to update some value using updatevalue it return nil , but will add new value and key into the dictionary
scores.updateValue(809, forKey: "player")
print(scores)

//If we want to not return nil in this then we can use nil coalescing operator
var temp = scores.updateValue(555, forKey: "player2") ?? 0 //If the value is of type Int then the nil coalescing value should also be Int
print(temp)

var languages = ["first": "swift", "second": "python", "third": "Java"]
print(languages)

var value = languages.updateValue("C++", forKey: "fourth") ?? "Default"
print(languages)
print(value)

languages.removeValue(forKey: "third")
print(languages)

var removedValue = languages.removeValue(forKey: "second")
//print("Removed values \(removedValue)")

print(languages)
var removedValue1 = languages.removeValue(forKey: "secon") ?? "No key is found"
print(removedValue1)


//accessing the elements using keys or values
print(languages.count)

print("Keys of dictionary are \(languages.keys)")
print("values of a dictionary are \(languages.values)")

//var fetchedValue = languages["first"]
//print("fetched value = \(fetchedValue)")

var fetchedValue = languages["Tenth"] ?? "Key is not present"
//print("Fetched Values = \(fetchedValue)")


//var person = ["name": "Harshwardhan", "Age": 19]

