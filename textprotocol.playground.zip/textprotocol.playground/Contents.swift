import UIKit

protocol passData {
    func recievedData(data:String)
}

