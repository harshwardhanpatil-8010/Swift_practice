import UIKit

//If
let temperature = 100
if temperature >= 100 {
    print("The water is boiling")
}

//If-else
if temperature >= 100 {
    print("The water is boiling")
} else {
    print("The water is not boiling")
}

//Boolean values
var number = 100
var result = number < 10


//NOT
if number != 100 {
    print("the number is not equal")
}

//AND
//else if ladder
var temp = 100
if temp <= 100 && temp >= 0 {
    print("Yes")
} else if temp != 0{
    print("No")
} else {
    print("No result")
}

//OR
if temp <= 100 || temp <= 0 {
    print("yes")
} else if temp != 0 {
    print("No")
} else {
    print("No result")
}

//Switch statement
let switchChar = 1
switch switchChar {
    case 1:
        print("One")
        break
    case 2:
        print("Two")
        fallthrough
    default:
    print("No answer")
}
//defalut should be there to remove the switch is exhaustive error
//If there is no break statement still no fallthrough will be there in swift
//fallthrough is used to go for the next case also
//break is used to break the case although the fallthrough is present there


//enum
enum Direction {
    case north
    case south
    case west
    case east
}

var direction: Direction = .north

switch direction {
case .north:
    print("North")
case .south:
    print("South")
case .west:
    print("West")
case .east:
    print("East")
}

//When using enum then we don't need to give default in a switch case


//Sitch case multiple conditions
//When we have to compare multiple conditions
let character = "a"
switch character {
case "a", "e", "i", "o", "u":
    print("It is a vowel")
default:
    print("It is not a vowel")
}

//Switch case with ranges
let distance = 100
switch distance {
case 0...9:
        print("The ranges is between 0 to 9")
case 10...99:
        print("The distance is between 10 to 99")
case 100...1000:
        print("The distance is more than hundred")
default:
        print("Provide the proper distance")
}

let tempTemparature = 70
switch tempTemparature {
case Int.min...64 :
    print("It is too cold")
case 65...75 :
    print("The temperature is just right")
case ..<65 :
    print("The teperature is just right")
default:
    print("It is too hot")
}

//Ternary operator
let a = 15
let b = 4
var largest: Int
largest = a > b ? a : b
print(largest)

