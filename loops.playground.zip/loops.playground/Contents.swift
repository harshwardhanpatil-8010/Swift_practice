import UIKit

//Loops

//when we need a variable
for index in 1...5 {
    print("Index: \(index)")
}

//when we don't want to give a variable we can use a _
for _ in 1...5 {
    print("Hello")
}


//Iterrating over an array
let names = ["Alice", "Bob", "Charlie"]
for name in names {
    print("Hello \(name)")
}

//It will itterate over single character in that string
for letter in "ABCDEFG" {
    print("The letter is \(letter)")
}

//using a function enumerated() to get the index value also
for (index, letter) in "ABCDEFG".enumerated() {
    print("\(index): \(letter)")
}

//Dictionary Iterration
let vehicles = ["Unicycle": 1, "bicycle": 2, "tricycle": 3, "Quad bike": 4]
for (vehicleName, wheels) in vehicles {
        print("Vehicle name: \(vehicleName), Number of wheels: \(wheels)")
}

///////////
let animals = ["Lion", "Tiger", "Bear"]
for index in 0..<animals.count {
    print("\(index) : \(animals[index])")
}

let base = 3
let power = 5
var answer = 1
for _ in 1...power {
    answer *= base
}
print(answer)



//Stride

//Used to itterate over a certain range of a number like in this case it is 5
let minInterval = 5 //or use 7 which is not divisible by 60
let minutes = 60
//It will not include the last element when using to depending on the by if it is divisible to the variable depending on to
for tickMark in stride(from: 0, to: minutes, by: minInterval) {
    print(tickMark)
}


//It will include the last element also when using through depending on the by if it is divisible to the variable depending on to
for tickMark in stride(from: 0, through: minutes, by: minInterval) {
    print(tickMark)
}


///While loops

//var numberOfLives = 3

//while numberOfLives > 0 {
//    print("I still have \(numberOfLives) lives")
//}


for i in 1...10 {
    var i = 0
//    count += 1
    i += 1
    print(i)
//    i += 1
}


var numberOfLives = 3
var stillAlive = true

while stillAlive {
    print("I still have \(numberOfLives) lives.")
    numberOfLives -= 1
    if numberOfLives == 0{
        print("Game Over!")
        stillAlive = false
    }
}



//Control transfer statements
for counter in -10...10 {
    print(counter)
    if counter == 0 {
        break
    }
 
}

for counter in -10...10 {
    print(counter)
    if counter == 0 {
        continue
    }
}

var number = 0
while number < 10{
    number += 1
    if number % 2 == 0 {
        continue
    }
    print("Odd number = \(number)")
}


var count = 0
repeat {
    print(count)
    count += 1
} while count < 0


//This is not working as it was working with repeat
while count < 0 {
    print(count)
    count += 1
}

