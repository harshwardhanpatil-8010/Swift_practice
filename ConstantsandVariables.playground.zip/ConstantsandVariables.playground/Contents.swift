import Cocoa

//define a constant
let name = "harshwardhan"
print(name)

//You cannot define two constants with same name
//name =" xyz"
let pi = 3.14
print(pi)

//define a variable
var age = 19
print(age)
age = 20
print(age)

//we use let instead of var for constants to access it faster

var isStudent = true

let defaultScore = 100
var playerSecondScore = defaultScore
var playerFirstScore = defaultScore

print(playerFirstScore)
print(playerSecondScore)

playerFirstScore = 500
print("Player First Score = \(playerFirstScore)")


//Naming Conventions practices
//No mathematical symbol for a variable name
//No spaces between the name
//Can't begin with a number

//Data Types
/* INT
 BOOL
 DOUBLE
 String*/
let playerName = "Harshwardhan"
var playerScore = 1000
var gameOver = false
var result = 95.5

//Type Safety
//playerScore = 98.3

//Type Inference
//Option + mouse click to check the data type of a var or let

//Type Annotation
//When you need to declare a let or var before assigning a value then we use type annotation
//var cityName: String = "Pune"

/*
 when you careate a const or a var before assigning it a value
 */
var cityName: String
cityName = "Pune"
print(cityName)

var number: Double = 30
print(number)

var lastName: Character = "p"
print(lastName)


//required values
var x: Int
x = 50
print(x)


//Numeric literal formatting
var largeNumber = 1000000000
print(largeNumber)

var veryLargeNumber = 1_000_000_000  //sugar syntax
print(veryLargeNumber)
