import UIKit

//Classes
let X = "Harshwardhan"

//Struct is value type
struct Vehicle1 {
    //If default value is not given then we need to create an initializer
    var name: String = "Harshwardhan"
    
}

//let myCar1 = Vehicle()
//myCar1.name = "Baleno"


///////////////

//Class is reference type
//class Vehicle {
    //If default value is not given then we need to create an initializer
 //   var name: String = "Harshwardhan"
    
//}

//let myCar = Vehicle()
//myCar.name = "Baleno"



class Person {
    let name: String
    init(name: String) {
        self.name = name
    }
    func sayHello(){
        print("Hello my name is \(name)")
    }
}
var person = Person(name: "Harshwardhan")
person.sayHello()



//Inheritance
class Vehicle { //Base Class
    var currentSpeed = 0.0
    var description: String {
        "travelling at \(currentSpeed) miles/hr"
    }
    func makeNoise(){
    }
}

class Bicycle: Vehicle {  //Super Class
    var hasBasket: Bool = false
}

class Tandem: Bicycle {  //Sub Class
    var noOfPassengers = 0
}

let tandem = Tandem()
tandem.hasBasket = true
tandem.currentSpeed = 22.0
tandem.noOfPassengers = 0
print("Tandem = \(tandem.description)")


//Function Override
class Train: Vehicle {
    override func makeNoise() {
        print("Choo choo")
    }
}

let train = Train()
train.makeNoise()

//In Swift you cannot inherit from multiple classes (multiple Inheritance)

//Only Computed properties and methods can be override in inheritance

class Bike {
    var currentSpeed: Int
    var engine: String
    
    init(currentSpeed: Int, engine: String) {
        self.currentSpeed = currentSpeed
        self.engine = engine
    }
}
var myBike = Bike(currentSpeed: 30, engine: "49cc")

class SuperBike: Bike {
    var topSpeed: Int
    init(topSpeed: Int, currentSpeed: Int, engine: String) {
        self.topSpeed = topSpeed
        super.init(currentSpeed: currentSpeed, engine: engine)
    }
}

var ducati = SuperBike(topSpeed: 320, currentSpeed: 100, engine: "999cc")
ducati.topSpeed
ducati.currentSpeed
ducati.engine


//The default Base class my have default values but you can use init in the subclass

//When you create an instance of a class
//- swift returns the address of that

