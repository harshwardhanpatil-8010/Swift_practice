import UIKit

//without delegate the data will not be send from the sender to receiver
//delegate is an optional variable
//delegate is mostly used when we have to send from second screen to first screenunlike segue which is used for sending data from first screen to second screen

protocol messenger {
    func passData(_ data: String)
}

class FirstView_Receiver: messenger {
    func passData(_ data: String) {
        print("Data received: \(data)")
    }
}

//delegate - a variable which is defined to a optional protocol
class SecondView_sender {
    var delegate: messenger?
    
    func sendData(_ data: String) {
        delegate?.passData(data)
    }
}
class ThirdView_Receiver: messenger {
    func passData(_ data: String) {
        print("New data is \(data)")
    }
}
class FourthView_Sender {
    var delegate: messenger?
    
    func sendData(_ data: String) {
        delegate?.passData(data)
    }
}

var firstView = FirstView_Receiver()
var secondView = SecondView_sender()
var thirdView = ThirdView_Receiver()
var fourthView = FourthView_Sender()

secondView.delegate = firstView
secondView.sendData("Hello, World!")
secondView.delegate = thirdView
secondView.sendData("Hello")

fourthView.delegate = thirdView
fourthView.sendData("new data")
