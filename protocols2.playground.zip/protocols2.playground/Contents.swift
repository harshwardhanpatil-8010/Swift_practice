import UIKit

//CUSTOM PROTOCOLS
protocol FullyNamed {
    var fullName: String { get }
func sayFullName()
}

struct Person: FullyNamed {
    var fullName: String
    
    func sayFullName() {
        print("My full name is \(fullName)")
    }
    
    var firstName: String
    var lastName: String
}

var person1: Person = Person(fullName: "Harshwardhan Patil", firstName: "Harswardhan", lastName: "Patil")
person1.sayFullName()
