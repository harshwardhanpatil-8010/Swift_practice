import UIKit

struct Student {
    var name: String
    //put a ? as an optional value to use nil
    var enrollmentYear: Int? //Declaring an optional integer
}

let firstStudent =  Student(name: "Harshwardhan", enrollmentYear: nil)
let secondStudent = Student(name: "Harsh", enrollmentYear: 2023)


//Specifying the type of an optional
var serverResponseCode: Int? = 404
var serverCode: Int? = nil
var serverCode2: Int?

//Force Unwrap
if firstStudent.enrollmentYear != nil {
    let actualYear = firstStudent.enrollmentYear!
    print("Enrolled in \(actualYear)")
}
//let unwrappedYear = firstStudent.enrollmentYear!


//If we just use the above method then we get the below error
/*__lldb_expr_26/optionals.playground:23: Fatal error: Unexpectedly found nil while unwrapping an Optional value
 Playground execution failed:

 error: Execution was interrupted, reason: EXC_BREAKPOINT (code=1, subcode=0x1957e6658).
 The process has been left at the point where it was interrupted, use "thread return -x" to return to the state before expression evaluation.

 * thread #1, queue = 'com.apple.main-thread', stop reason = EXC_BREAKPOINT (code=1, subcode=0x1957e6658)
     frame #0: 0x00000001957e6658 libswiftCore.dylib`closure #1 (Swift.UnsafeBufferPointer<Swift.UInt8>) -> () in closure #1 (Swift.UnsafeBufferPointer<Swift.UInt8>) -> () in closure #1 (Swift.UnsafeBufferPointer<Swift.UInt8>) -> () in Swift._assertionFailure(_: Swift.StaticString, _: Swift.StaticString, file: Swift.StaticString, line: Swift.UInt, flags: Swift.UInt32) -> Swift.Never + 224
     frame #1: 0x00000001957e6448 libswiftCore.dylib`closure #1 (Swift.UnsafeBufferPointer<Swift.UInt8>) -> () in closure #1 (Swift.UnsafeBufferPointer<Swift.UInt8>) -> () in Swift._assertionFailure(_: Swift.StaticString, _: Swift.StaticString, file: Swift.StaticString, line: Swift.UInt, flags: Swift.UInt32) -> Swift.Never + 184
     frame #2: 0x00000001957e634c libswiftCore.dylib`closure #1 (Swift.UnsafeBufferPointer<Swift.UInt8>) -> () in Swift._assertionFailure(_: Swift.StaticString, _: Swift.StaticString, file: Swift.StaticString, line: Swift.UInt, flags: Swift.UInt32) -> Swift.Never + 328
     frame #3: 0x00000001957e5f94 libswiftCore.dylib`Swift._assertionFailure(_: Swift.StaticString, _: Swift.StaticString, file: Swift.StaticString, line: Swift.UInt, flags: Swift.UInt32) -> Swift.Never + 168
     frame #4: 0x0000000104ec0834 $__lldb_expr27`main at optionals.playground:0
     frame #5: 0x0000000104b01c60 optionals`linkResources + 264
     frame #6: 0x0000000180429134 CoreFoundation`__CFRUNLOOP_IS_CALLING_OUT_TO_A_BLOCK__ + 20
     frame #7: 0x0000000180428898 CoreFoundation`__CFRunLoopDoBlocks + 348
     frame #8: 0x0000000180423450 CoreFoundation`__CFRunLoopRun + 808
     frame #9: 0x0000000180422cec CoreFoundation`CFRunLoopRunSpecific + 536
     frame #10: 0x0000000191004d00 GraphicsServices`GSEventRunModal + 164
     frame #11: 0x0000000185c597d4 UIKitCore`-[UIApplication _run] + 796
     frame #12: 0x0000000185c5dba0 UIKitCore`UIApplicationMain + 124
   * frame #13: 0x0000000104b01dd0 optionals`main + 368
     frame #14: 0x0000000104b1d3d4 dyld_sim`start_sim + 20
     frame #15: 0x0000000104c02b98 dyld`start + 6076 */


//Using if let or if var we don't get the above error
if let unwrappedYear = firstStudent.enrollmentYear {
    print("Enrolled in \(unwrappedYear)")
} else {
    print("Not enrolled yet")
}


//Return values

let String = "123"
let String2 = "Harshwardhan"
//We can only convert the intgers written inside a string to int but we cannot convert an String to an Int  although it is Int(String)
let possibleNumber = Int(String2)
//print(possibleNumber)
if let number = possibleNumber {
    print("Converted to Int: \(number)")
} else {
    print("Couldn't convert to Int")
}


//Defining

//We can use if var or we can use if let
func fullName(firstName: String, middleName: String?, lastName: String) {
    if let middleName = middleName {
        print("\(firstName) \(middleName) \(lastName)")
    } else {
        print("\(firstName) \(lastName)")
    }
}
//If we don't provide middleName value then the else statement will be executed
fullName(firstName: "Harshwardhan", middleName: "Sandip", lastName: "Patil")

///////
@MainActor func getURL(_ string: String)-> String? {
    if let url = URL(string: string), UIApplication.shared.canOpenURL(url) {
        return "\(url)"
    } else {
        return nil
    }
}
let urlString = "https://www.apple.com"

if let url = getURL(urlString) {
    print(url)
} else {
    print("Invalid URL")
}
///////


//Failable Initializers
struct Toddler {
    var birthName: String
    var monthsOld: Int
    init?(birthName: String, monthsOld: Int) {
        if monthsOld < 12 || monthsOld > 36 {
            return nil
        } else {
            self.birthName = birthName
            self.monthsOld = monthsOld
        }
    }
}
if let aBaby = Toddler(birthName: "Harsh", monthsOld: 15) {
    print(aBaby)
} else {
    print("not a toddler")
} //if the condition is not fullfilling so it is returning a nil value



//Optional chaining
struct Person {
    var age: Int
    var residence: Residence?
}
struct Residence {
    var address: Address?
}

struct Address {
    var buildingNumber: String?
    var streetName: String?
    var appartmentNumber: Int?
}
let aPerson = Person(age: 15, residence: Residence(address: (Address(buildingNumber: "New", streetName: "Kothrud", appartmentNumber: 7))))

//Good Practice
if let theAppartmnetNumber = aPerson.residence?.address?.appartmentNumber {
    print("They live in appartment Number \(theAppartmnetNumber)")
}

/*
//Not a good practice
if let theResidence = aPerson.residence {
    if let theAddress = theResidence.address {
        if let theAppartmentNumber = theAddress.appartmentNumber {
            print("They live in appartment number \(theAppartmentNumber)")
        }
    }
} */


//Assignment
class Student1 {
    let name: String?
    let age: String?
  
    let possibleAge = Int(String)
    var address: Address1?
    init?(name: String, possibleAge: Int, address: Address1) {
        self.name = name
        self.possibleAge = possibleAge
        self.address = address
    }
}
struct Address1 {
    var street: String?
    var city: String?
}

let newStudent = Student1(name: "Harshwardhan", possibleAge: "20" ,address: Address1(street: "Kothrud", city: "Pune"))

if let studentName = newStudent?.name {
    print("Name = \(studentName)")
}
if let studentage = newStudent?.possibleAge {
    print("Age = \(studentage)")
}
if let studentCity = newStudent?.address?.city {
    print("City = \(studentCity)")
}
