import UIKit


import foundation
struct Note: Codable {
    let title: String
    let text: String
    let timestamp: Date
}

let note1 = Note(title: "Note One", text: "This is sample note", timestamp: Date())

let note2 =  Note(title: "Note Two", text: "Another sample note", timestamp: Date())

let note3 = Note(title: "Note Three", text: "Yet another note", timestamp: Date())

let notes =  [note1, note2, note3]

//.documentDirectory is for url

let documentDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!

let archiveURL = documentDirectory.appendingPathComponent("notes_test").appendingPathExtension("plist")

print(documentDirectory.path)
let propertyListEncoder =  PropertyListEncoder()

if let encodedNote = try? propertyListEncoder.encode(notes)
    print("Encoded Note: \(encodedNote)")
    try? encodedNote.write(to: archiveURL, options: .noFileProtection)
    let propertyListDecoder = PropertyListDecoder()
    if let retrivedNoteData =  try? Data(contentsOf: archiveURL)
    let decodedNote =  try? propertyListDecoder.decode(Array<Note>.self, from: retrivedNoteData) {
    
print("Decoded Data: \(decodedNote)")
    
}
    
    
    
