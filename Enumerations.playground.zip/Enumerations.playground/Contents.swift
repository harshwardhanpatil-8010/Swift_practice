import UIKit

//Enumerations
//Grouping of related values with typesafety

//Enum without type
enum CompassPoint {
    case north
    case south
    case east
    case west
}
/*
enum CoffeeSize {
    case small
    case medium
    case large
}
*/

enum CoffeeSize {
    case small, medium, large
}

//var myCoffeeSize: CoffeeSize = .medium
var myCoffeeSize = CoffeeSize.medium
myCoffeeSize = .small

//By using Enum we do not need to declare a default case in switch case
switch myCoffeeSize {
case .small:
    print("I have ordered small size coffee")
case .medium:
    print("I have ordered medium size coffee")
case .large:
    print("I have ordered large size coffee")
}

/////------------------------------------------
if myCoffeeSize == .small {
    print("I have ordered a small size coffee")
}

/////-----------------------------------------
enum Genre {
    case action, adventure, comedy, romance
}

struct Movie {
    var title: String
    var releaseYear: Int?
    var genre: Genre
}

let myMovie = Movie(title: "Inception", releaseYear: 2010, genre: .action)

//Optional binding for release Year
print("******************************************")
if let releaseYear = myMovie.releaseYear {
    print("\(releaseYear)")
} else {
    print("No release year provided")
}


//Enum with type
enum CoffeeType: String {
    case latte = "Creamy Latte"
    case cappuccino = "Espresso Cappuccino"
    case macchiato = "Cold brew macchiato"
}

struct CoffeeOrder {
    var size: CoffeeSize
    var type: CoffeeType
    var payment: PaymentMethod  //Associated property
}

//Associated properties
enum PaymentMethod {
    case cash
    case applePay(deviceID: Int)
    case creditCard(number: String, expirationDate: String)
    var description: String {
        switch self {
        case .cash :   //If there are any parameters then only we use let so in this .cash was not given with any parameter but for applepay and creditCard there are parameters
            return "Payment done by cash"
        case let .applePay(deviceID):
            return "Payment done by apply pay \(deviceID)"
        case let .creditCard(number, expirationDate) :
            return "Payment done by credit card with number \(number) of expiration date \(expirationDate)"
        }
    }
}
var paymentDone = PaymentMethod.applePay(deviceID: 67)

print(paymentDone)
print("******************************************")

//Enum with type and associated properties
func describingOrder(_ order: CoffeeOrder) {   //struct CoffeeOrder
    print("I have ordered a \(order.type.rawValue) of \(order.size) size coffee and payment is done by \(order.payment.description)")  //rawValue is the value given to the type
}
let myOrder = CoffeeOrder(size: .small, type: .latte, payment: .creditCard(number: "234-234-3454", expirationDate: "09/25"))
describingOrder(myOrder)



//Case Iterable
//CaseIterable is a protocol and enum is adopting the protocol
enum CoffeeSize1: String, CaseIterable {   //Protocols should only be written in last after any data type declaration
    case small = "small"
    case medium = "medium"
    case large = "large"
}

for sizes in CoffeeSize1.allCases {  //allCases is used to access all the cases inside a enum
    print(sizes.rawValue)
}

//Count the number of cases
let numberOfChoices = CoffeeSize1.allCases.count
print(numberOfChoices)




//Implicity Assigned Raw Values
enum Planet: Int {
    case mercury = 1, venus, earth, mars, jupiter, saturn, uranus, neptune
}
//we have not given any raw value to earth still it will give a value on the basis of first value given to a case
let bestPlanet: Planet = .earth
print("RawValue for earth \(bestPlanet.rawValue)")



//Recursive Enums
//3 types of arithmetic expression an enum can have  -- number, addition, multiplication

indirect enum ArithmeticExpression {
    case number(Int)
    case addition(ArithmeticExpression, ArithmeticExpression)
    case multiplication(ArithmeticExpression, ArithmeticExpression)
}

let number1 = ArithmeticExpression.number(5)
let number2 = ArithmeticExpression.number(4)
let number3 = ArithmeticExpression.number(2)

let sum = ArithmeticExpression.addition(number1, number2)
let multiplication = ArithmeticExpression.multiplication(sum, number3)

func evaluate(_ expression: ArithmeticExpression)-> Int {
    switch expression {
    case let .number(value):
        return value
    case let .addition(left, right):
        return evaluate(left) + evaluate(right)
    case let .multiplication(left, right):
        return evaluate(left) * evaluate(right)
    }
}
print(evaluate(multiplication))



//Assignment
enum States {
    case available
    case checkedOut
    case reserved
}
struct Book {
    var borrowerName: String?
}
