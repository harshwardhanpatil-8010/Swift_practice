// Strings
import UIKit
//mutability
var greeting = "Hello, playground"
//immutability
let fixedGreeting = "Hello, playground"

let greet = "Hello, world!"
var greetingMessage = greet
greetingMessage = "hello"
print(greet)
print(greetingMessage)

//Multi line strings
let joke = """
Q. Why + operator broke up with - operator
A. Sure to non able to handle negativity 
"""
print(joke)

// escape character \
let learning = "I am \r learning \n\"swift\""
print(learning)

// \" for printing double qoutes inside a string using an escape character
// \r return to next line
// \t for tab
// \n for new line


//isEmpty
//Empty string
var myString = String()
// var myString = ""
if myString.isEmpty {
    print("String is empty")
}

//Concatenation
let firstName = "Harshwardhan"
let lastName = "Patil"
let fullName = firstName + " " + lastName
print(fullName)

//append
var greeting2 = "Hello"
greeting2 += fullName
print(greeting2)



//Interpolation
let age = 18
print("\(greeting2) is \(age) years old.")

print("Five times of 6 is \(5 * 6) \n")


let price: Double = 99
let qty = 10
let tax = 15
print("""
      Item: \t\tBook
      price: \t\t\(price)
      Quantity: \t\(qty)
      Tax: \t\t\t\(tax)
      total: \t\t\((price * Double(qty)) + (Double(tax)/100 * price))
    """)




let month = "January"
let otherMonth = "january"

if month == otherMonth {
        print("Both the months are same")
}
if month != otherMonth {
    print("Both the months are not equal")
}

///////////
if firstName.lowercased() == "HarshWardhan".lowercased() {
    print("They are same")
}


//prefix and sufix
let password = "123456"
password.hasSuffix("456")
password.hasPrefix("123")


//contains
let learningNew = "I am \r learning \n\"swift\""
if learningNew.contains("learning"){
    print("I am loving it")
}

//check length using count
print(password.count)
if password.count < 8 {
    print("Password must be 8 characters long")
}


let operation = "Success"
switch operation.lowercased() {
case "success" :
    print("I am learning Swift")
default :
    print("Default")
}



//unicodes
let love = "\u{2665}"
print("I \(love) swift")

