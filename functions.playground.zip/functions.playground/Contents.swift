import UIKit

var greeting = "Hello, playground"
//Functions
func displayPi() {  //Function signature or function prototype - what your function is expected
    print("3.141")
}
displayPi()


///parameterized functions
func triple(value: Int /*type annotation*/) {
    let result = value * 3
    print("Result = \(result)")
}

triple(value: 3)


//Multiple parameters
func multiply(firstNumber: Int, secondNumber: Int) {
    let result = firstNumber * secondNumber
    print("result = \(result)")
}

multiply(firstNumber: 20, secondNumber: 30)

//Return values
func multiplyNew(firstNum: Int, secondNum: Int) -> Int {
    let result = firstNum * secondNum
    return result
}

var resultValue = multiplyNew(firstNum: 14, secondNum: 5)
print("Result value = \(resultValue)")

print(multiplyNew(firstNum: 20, secondNum: 10))

print("Result = \(multiplyNew(firstNum: 15, secondNum: 20))")   //Interpolation


/////////////////// When there is only one single statement inside the function then you don't need to give a return statement
func multiplySecond(firstNum: Int, secondNum: Int) -> Int {
     firstNum * secondNum
}

print("result = \(multiplySecond(firstNum: 3, secondNum: 2))")



func sayHello(name: String ) {
    print("Hello \(name)")
}
sayHello(name: "Harshwardhan")


func sayHello2(to: String, and: String) {
    print("Hello \(to) and \(and)")
}
//Internal labels
sayHello2(to: "harshwardhan", and: "harsh")



/// External labels - person, anotherPerson
func sayHello3(to person: String, and anotherPerson: String) {
    print("hello \(person) and \(anotherPerson)")
}
sayHello3(to: "Harshwardhan", and: "Harsh")  //Actual arguements - Harshwardhan & harsh
//Formal arguements - person & anotherPerson
//Arguement labels - to & and



//Ommitting labels
//We can call a function without using the argument label at the time of function call
func add(_ firstNumber: Int, _ secondNumber: Int) {
    print("Addition = \(firstNumber + secondNumber)")
}
add(10, 20)


func sub(_ firstNum: Int, to secondNum: Int) -> Int {
    firstNum + secondNum
}
let total = sub(14, to: 6)
print(total)

///only one can be omitting and other one can be decalred as an arguement to make code more readable
func incrementTheNumber(_ value: Int, by number: Int) {
    print("Incremented value = \(value + number)")
}
incrementTheNumber(15, by: 4)


//Default parameter values
//If passing your own values then default values will get overwritten
func dispUserInfo(name: String, place: String = "Pune") {
    print("Name = \(name) Place = \(place)")
}
dispUserInfo(name: "Harswardhan")
dispUserInfo(name: "Harshwardhan", place: "Akola")

///////////
func sum(_ num1: Int = 0, _ num2: Int = 0, _ num3: Int = 0) {
    print(num1 + num2 + num3)
}
sum()
sum(10)
sum(25, 20)
sum(20, 30, 50)


func doubleValue(_ num1: Int) -> Int {
    num1 * 2
}
print(doubleValue(5))


func findMinMax(_ firstNumber: Int, _ secondNumber: Int) -> (min: Int, max: Int) {
    if firstNumber > secondNumber {
        return(min: secondNumber, max: firstNumber)
    } else {
        return(min: firstNumber, max: secondNumber)
    }
}

let (min, max) = findMinMax(10, 40)
print("Minimum = \(min) and maximum = \(max)")


//Or
var result = findMinMax(30, 40)
print(result.min)
print(result.max)
